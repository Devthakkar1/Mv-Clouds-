package JavaTask.Day9;

public class Task6 {
    public static void main(String[] args) {
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 8; j++) {
                if ((j == 4 && i >= 0) || (i == 4 && j >= 0) || (j == 0 && i <= 3) || (i == 0 && j >= 5)
                        || (i == 8 && j <= 3) || (j == 8 && i >= 5)) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
