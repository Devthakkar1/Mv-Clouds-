// without using sort method
// using sort method
package JavaTask.Day9;

// import java.util.Arrays;

public class Task2 {
    public static void main(String[] args) {
        String str="mvclouds";

        char arr[]= str.toCharArray();

        char temp;

        for(int i=0;i< arr.length;i++){
            for(int j=i+1;j< arr.length;j++){
                if (arr[i]>arr[j]){
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        System.out.println(new String(arr));

        //method 2
        // String str1= "clouds";
        // char[] CharArray= str1.toCharArray();
        // Arrays.sort(CharArray);
        // System.out.println(new String(CharArray));
    }
}
