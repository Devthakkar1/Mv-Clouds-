package JavaTask.Day9;
import java.util.*;

public class Task4 {
    public static void main(String[] args) {
        for(int row=1;row<=5;row++){
            for(int col=1; col<=row;col++){
                if(col==1 || row==5 || row==col){
                System.out.print("*");
                } else{
                    System.out.print(" ");
                }
            }
        System.out.println();

        }

    }
}
