package JavaTask.Day9;

public class Task1 {
    public static void main(String[] args) {
        
    
    String str1= "WELCOME TO MV CLOUDS";
    String str2="";
    
    for(int i=0; i<str1.length(); i++){
        if(str1.charAt(i)!=' '){
            str2=str2+str1.charAt(i);
        }
    }
    System.out.println(str2);
    // String trimmedString =  str.trim();

    // System.out.println(trimmedString);

    // String str1 =str.replaceAll("\\s", "");
    // System.out.println(str1);
    }
}
