package JavaTask.Day9;


public class Task7  {


       public static void main(String[] args) {
        
        int rows = 9;
        int cols = 9;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= cols; j++) {
                if (j == 1 || j == cols || j == i || j == cols - i + 1) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println("");
        }
    }}
