package JavaTask.Day9;
import java.util.Arrays;
public class Task3 {
    public static void main(String[] args) {
        int num[]={98,98,72,94,75,73,92,36,28,34};

        int n=num.length;

        int highest = Integer.MIN_VALUE;
        int secondHighest =Integer.MIN_VALUE;

        for(int i=0; i<n; i++){
            if(num[i]>highest){
                secondHighest = highest;
                highest = num[i];
            }

            if(num[i]< highest && num[i] >secondHighest){
                secondHighest =num[i];
            }
        }

        System.out.println("second largest number:" +secondHighest);

    }
}
